﻿using System;
using System.Text;
using System.Collections;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;
namespace Que2_ass
{
    delegate void swapper<T>(T x, T y);
    class employee
    {
        public int id;
        public string name;
        public int salary;

    }

    class Program
    {
        static public void swap(employee e, employee e1)
        {
            int sal = e.salary;
            e.salary = e1.salary;
            e1.salary = sal;
            Console.WriteLine(e.salary + " " + e1.salary);
        }
        static void Main(string[] args)
        {
            BinaryFormatter bf = new BinaryFormatter();
            Stream s = new FileStream("File_1.txt", FileMode.Create, FileAccess.Write);
            employee e = new employee();
            e.id = 1;
            e.name = "Rhutuja";
            e.salary = 60000;
            employee e1 = new employee();
            e1.id = 2;
            e1.name = "rhutuja";
            e1.salary = 50000;
            swapper<employee> sw = new swapper<employee>(swap);
            sw(e, e1);
            Console.ReadLine();





        }


    }

}


